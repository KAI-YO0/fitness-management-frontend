<template>
    <div class="content">
    <nav>
            <i class='bx bx-menu'></i>
            <form action="#">
                <div class="form-input">
                    <input type="search" placeholder="Search...">
                    <button class="search-btn" type="submit"><i class='bx bx-search'></i></button>
                </div>
            </form>
            <input type="checkbox" id="theme-toggle" style="display: none;">
            <label for="theme-toggle" class="theme-toggle"></label>
            <a href="#" class="profile">
                <img src="../assets/46.png">
            </a>
        </nav>
    </div>
    
</template>