<template>
    <Nav class="bg-black fixed w-full z-50 top-0"></Nav>
    <div class="about ">

        <section class="py-10 bg-black  dark:bg-gray-900   ">

            <!-- <div class="absolute   text-white  bg-[#EF8964] h-[88px] w-[146px] right-0 mr-[295px] mt-8  rounded-xl">
              <div class="relative">
                  <div class="absolute bg-[#EFA082] rounded-full px-1 py-1 ml-6 mt-3  ">
                      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 16 16" fill="none">
                          <g clip-path="url(#clip0_151_131)">
                              <path
                                  d="M14.8234 4.7254C14.6138 4.47501 14.2403 4.44209 13.9899 4.65089L12.349 6.02935L11.5943 4.15964C11.5675 4.08946 11.5267 4.03054 11.4799 3.97856C11.3257 3.63546 11.058 3.34088 10.6889 3.17019C10.5286 3.09742 10.3631 3.05843 10.1977 3.03937C10.1613 3.02031 10.1283 2.99518 10.0868 2.98218L7.19901 2.17729C7.03699 2.1331 6.87411 2.16169 6.74068 2.23967C6.58213 2.29339 6.4461 2.40862 6.38112 2.57584L5.29378 5.37174C5.17594 5.67585 5.3267 6.01895 5.63168 6.13852C5.93492 6.25635 6.27888 6.10473 6.39758 5.79975L7.31598 3.43878L8.63119 3.80441C8.59913 3.85639 8.56447 3.90491 8.53848 3.96036L6.85245 7.61488C6.82819 7.6686 6.81519 7.72318 6.79786 7.77863L4.7488 11.2139L1.31955 12.3611C0.931399 12.6513 0.84909 13.198 1.13587 13.5862C1.42439 13.9752 1.97282 14.0575 2.36011 13.7707L5.86907 12.5621C5.97651 12.4841 6.05448 12.3819 6.1134 12.2718C6.15759 12.225 6.20784 12.1878 6.24163 12.1297L7.46327 10.0815L9.63189 11.9296L7.31165 14.5444C6.99194 14.9049 7.024 15.4602 7.38616 15.7791C7.74745 16.1005 8.30108 16.0667 8.62252 15.7046L11.5181 12.4425C11.6082 12.342 11.6619 12.2259 11.6983 12.1046C11.7199 12.0388 11.7199 11.9703 11.7251 11.9019C11.7251 11.8672 11.7381 11.836 11.7355 11.804C11.7277 11.5648 11.6307 11.3326 11.4349 11.1672L9.43955 9.46553C9.58337 9.32864 9.70554 9.16575 9.79391 8.97428L11.0866 6.17491L11.5007 7.27785C11.5181 7.37575 11.551 7.47192 11.6203 7.5525C11.6827 7.62701 11.7624 7.67639 11.8473 7.71105C11.856 7.71538 11.8664 7.71625 11.8768 7.71885C11.9305 7.73791 11.9851 7.7561 12.0414 7.7587C12.1081 7.76477 12.1757 7.7561 12.2441 7.73704C12.2459 7.73618 12.2467 7.73618 12.2467 7.73618C12.2649 7.73184 12.2831 7.73531 12.3013 7.72751C12.3975 7.69112 12.4711 7.62961 12.5344 7.5577L14.8893 5.55889C15.1397 5.34835 15.034 4.97579 14.8234 4.7254Z"
                                  fill="white" />
                              <path
                                  d="M11.8447 3.30102C12.7562 3.30102 13.4952 2.56206 13.4952 1.65051C13.4952 0.738959 12.7562 0 11.8447 0C10.9331 0 10.1942 0.738959 10.1942 1.65051C10.1942 2.56206 10.9331 3.30102 11.8447 3.30102Z"
                                  fill="white" />
                          </g>
                          <defs>
                              <clipPath id="clip0_151_131">
                                  <rect width="16" height="16" fill="white" />
                              </clipPath>
                          </defs>
                      </svg>
                  </div>
                  <div class="absolute flex top-10 ml-6">
                      <h1 class="text-4xl font-medium">4,95</h1>
                      <span class="text-md text-[#EFEDE8A6] mt-4 ml-2 font-normal">km</span>
                  </div>
              </div>
          </div>

          <div
              class="absolute bg-[#7A29DC] text-white h-[80px] w-[150px] rounded-xl right-0 bottom-0 mr-[255px] mb-[160px]">
              <div class="relative px-5 py-2">
                  <div class="grid gap-2">
                      <h1 class="font-medium text-4xl">500</h1>
                      <h1 class="absolute font-bold right-[45px] top-[8px] text-3xl">+</h1>
                  </div>

                  <h2 class="text-[11px] mt-1 text-[#EFEDE8A6]">Free Workout Videos</h2>
              </div>
          </div>

          <div
              class="absolute bg-[#303030] text-white px-4 py-3 h-[80px] w-[170px] right-0 rounded-xl mt-[300px] mr-[580px]">
              <div class="flex gap-2">
                  <div class="mt-2"><svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40"
                          fill="none">
                          <circle cx="20" cy="20" r="20" fill="#EF8963" />
                          <path d="M30 20L15 28.6603L15 11.3397L30 20Z" fill="#FAFAF9" />
                      </svg></div>
                  <div>

                      <div class=" text-2xl font-medium">350
                          <span class="absolute top-[10px]">+</span>
                      </div>

                      <div class="text-[14px] text-[#EFEDE8A6]">Video tutorial</div>
                  </div>
              </div>
          </div> -->


            <div class="lg:px-20 mx-auto max-w-screen-2xl    grid lg:grid-cols-2  justify-items-center">
                <div class="flex flex-col justify-center py-8 px-8 lg:px-20 ">
                    <h1
                        class="mb-4  text-4xl font-extrabold tracking-tight leading-none  md:text-5xl lg:text-8xl text-white">
                        WORK OUT</h1>
                    <h1
                        class="mb-4 lg:mb-10  text-4xl font-extrabold tracking-tight leading-none  md:text-5xl lg:text-8xl text-white">
                        GYM BALL</h1>
                    <p class=" text-lg font-normal text-white lg:text-md dark:text-gray-400">Fitness is not about being
                        better than someone. Fitness is about being better than the person you were yesterday.
                        growth.</p>
                </div>
                <div>
                    <div class=" md:py-24 py-10 ">
                        <img class=" h-[28rem]   " src="../assets/fit1.png">
                    </div>
                </div>
            </div>
        </section>
    </div>


    <br>
    <br>


    <div class="lg:flex lg:px-24 md:px-24 py-16 ">
        <div class="md:shrink-0 px-20 ">
            <img class=" w-full object-cover   md:w-96   " src="../assets/bolgym.png"
                alt="Modern building architecture">
        </div>
        <div class="p-6 lg:p-24  lg:mt-24">
            <div class="uppercase tracking-wide text-2xl text-indigo-500 font-semibold mb-8">GYM BALL</div>
            <a href="#" class="block mt-1 text-lg leading-tight font-medium text-black hover:underline">GYM BALL is the most popular cycling exercise class</a>
            <p class="mt-2 text-slate-500"> GYM BALL
                A total strength and cardio workout using every single muscle. Doubled up with a Fitball®, it challenges
                your core muscles, strengthens the entire body while improving flexibility and balance. Fueling you with
                energy and confidence.</p>
        </div>
    </div>

    <br>
    <br>
    <br>

    <div class="">
        <div class="grid sm:grid-cols-3 sm:gap-2 px-5 mb-48  h-auto w-full">
            <div class="grid justify-center gap-8 pt-8  font-bold text-3xl">DURATION
                <div class="grid justify-center my-5">
                    <svg xmlns="http://www.w3.org/2000/svg" height="52" width="42" viewBox="0 0 448 512">
                        <path fill="#95979d"
                            d="M176 0c-17.7 0-32 14.3-32 32s14.3 32 32 32h16V98.4C92.3 113.8 16 200 16 304c0 114.9 93.1 208 208 208s208-93.1 208-208c0-41.8-12.3-80.7-33.5-113.2l24.1-24.1c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L355.7 143c-28.1-23-62.2-38.8-99.7-44.6V64h16c17.7 0 32-14.3 32-32s-14.3-32-32-32H224 176zm72 192V320c0 13.3-10.7 24-24 24s-24-10.7-24-24V192c0-13.3 10.7-24 24-24s24 10.7 24 24z" />
                    </svg>
                </div>
                <div class=" flex justify-center  font-medium text-xl">60 minis</div>
            </div>


            <div class="grid justify-center gap-8 pt-8 font-bold text-3xl">COMPLEXITY
                <div class="grid justify-center my-5">
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" height="52" width="42" viewBox="0 0 384 512">
                            <path fill="#95979d"
                                d="M372.5 256.5l-.7-1.9C337.8 160.8 282 76.5 209.1 8.5l-3.3-3C202.1 2 197.1 0 192 0s-10.1 2-13.8 5.5l-3.3 3C102 76.5 46.2 160.8 12.2 254.6l-.7 1.9C3.9 277.3 0 299.4 0 321.6C0 426.7 86.8 512 192 512s192-85.3 192-190.4c0-22.2-3.9-44.2-11.5-65.1zm-90.8 49.5c4.1 9.3 6.2 19.4 6.2 29.5c0 53-43 96.5-96 96.5s-96-43.5-96-96.5c0-10.1 2.1-20.3 6.2-29.5l1.9-4.3c15.8-35.4 37.9-67.7 65.3-95.1l8.9-8.9c3.6-3.6 8.5-5.6 13.6-5.6s10 2 13.6 5.6l8.9 8.9c27.4 27.4 49.6 59.7 65.3 95.1l1.9 4.3z" />
                        </svg>
                    </div>
                </div>
                <div class=" flex justify-center gap-8  font-medium text-xl">Easy</div>
            </div>

            <div class="grid justify-center gap-8 pt-8 font-bold text-3xl">INTENSITY
                <div class="grid justify-center my-5">
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" height="52" width="42" viewBox="0 0 512 512">
                            <path fill="#95979d"
                                d="M224 96a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zm122.5 32c3.5-10 5.5-20.8 5.5-32c0-53-43-96-96-96s-96 43-96 96c0 11.2 1.9 22 5.5 32H120c-22 0-41.2 15-46.6 36.4l-72 288c-3.6 14.3-.4 29.5 8.7 41.2S33.2 512 48 512H464c14.8 0 28.7-6.8 37.8-18.5s12.3-26.8 8.7-41.2l-72-288C433.2 143 414 128 392 128H346.5z" />
                        </svg>
                    </div>
                </div>
                <div class=" flex justify-center  font-medium text-xl">Medium</div>
            </div>



        </div>

    </div>









    <div class="contrainner   h-full w-auto">

        <div class="bg-black text-white text-lg font-bold mx-10 p-6 flex flex-wrap justify-around h-20 gap-4">
            <div class="">MON</div>
            <div class="">TUE</div>
            <div class="">WED</div>
            <div class="">THU</div>
            <div class="">FRI</div>
        </div>



        <div
            class="grid mb-8 mx-10 border border-gray-200 rounded-lg shadow-sm dark:border-gray-700 md:mb-12 md:grid-cols-3 bg-white dark:bg-gray-800">
            <figure
                class="flex flex-col items-center justify-center p-8 text-center bg-white border-b border-gray-200 rounded-t-lg lg:rounded-t-none md:rounded-ss-lg md:border-e dark:bg-gray-800 dark:border-gray-700">
                <blockquote class="max-w-2xl mx-auto pt-8 mb-4 text-gray-500 lg:mb-8 dark:text-gray-400">
                    <h3 class="text-2xl font-semibold text-gray-900 dark:text-white">TUESDAY </h3>
                    <p class="my-4 text-xl">10.00 - 11.00</p>
                </blockquote>
            </figure>
            <figure
                class="flex flex-col items-center justify-center p-8 text-center bg-white border-b border-gray-200 md:rounded-es-lg md:border-b-0 md:border-e dark:bg-gray-800 dark:border-gray-700">
                <blockquote class="max-w-2xl mx-auto pt-8 mb-4 text-gray-500 lg:mb-8 dark:text-gray-400">
                    <h3 class="text-2xl font-semibold text-gray-900 dark:text-white">MONDAY</h3>
                    <p class="my-4 text-xl">13.00 - 14.00 </p>
                </blockquote>
            </figure>
            <figure
                class="flex flex-col items-center justify-center p-8 text-center bg-white border-b border-gray-200 md:rounded-es-lg md:border-b-0 md:border-e dark:bg-gray-800 dark:border-gray-700">

                <figcaption class="flex items-center justify-center   ">
                    <img class="rounded-full w-24 h-24"
                        src="https://flowbite.s3.amazonaws.com/blocks/marketing-ui/avatars/jese-leos.png"
                        alt="profile picture">
                    <div class="space-y-0.5 font-medium dark:text-white text-left rtl:text-right ms-6">
                        <div>Jese Leos</div>
                        <div class="text-sm text-gray-500 dark:text-gray-400">Coach</div>
                    </div>
                </figcaption>
               

                <button type="button" @click="handleButtonClick" data-modal-target="crud-modal"
                    data-modal-toggle="crud-modal"
                    class="w-52 my-6 text-white   bg-gray-800 hover:bg-gray-900 focus:outline-none focus:ring-4 focus:ring-gray-300 font-medium rounded-lg text-sm px-5 py-2.5  mb-2 dark:bg-gray-800 dark:hover:bg-gray-700 dark:focus:ring-gray-700 dark:border-gray-700">
                    Reserve
                </button>


                <div id="crud-modal" tabindex="0" aria-hidden="true"
                    class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] max-h-full">
                    <div class="relative p-4 w-full max-w-md max-h-full">

                        <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">

                            <div
                                class="flex items-center justify-between p-4 md:p-5 border-b rounded-t dark:border-gray-600">
                                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                                    Reserve
                                </h3>
                                <button type="button"
                                    class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
                                    data-modal-toggle="crud-modal">
                                    <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                        fill="none" viewBox="0 0 14 14">
                                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                            stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                                    </svg>
                                    <span class="sr-only">Close modal</span>
                                </button>
                            </div>

                            <form class="p-4 md:p-5">
                                <div class="grid gap-4 mb-4 grid-cols-2">
                                    <div class="col-span-2 flex">
                                        
                                        <input type="text" v-model="userObject.firstname"
                                        class="w-32 flex-1 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500 mr-2"
                                        placeholder="First name">
                                        <input type="text" v-model="userObject.lastname"
                                        class="w-32 flex-1 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500 ml-2"
                                        placeholder="Last name">
                                    </div>


                                    <div class="col-span-2 sm:col-span-1">
                                        <label for="category"
                                            class="block mb-2 text-sm  text-left font-medium text-gray-900 dark:text-white">Select
                                            Class</label>
                                        <select id="classCategory"
                                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500">
                                            <option></option>
                                            <option value="GYMBALL">GYM BALL</option>
                                            <!-- <option value="trainer">BIKE TOUR</option>
                                                <option>SPIN</option>
                                                <option>BODYPUMP</option>
                                                <option>MAXED TERRAIN</option>
                                                <option>GYMBALL</option> -->
                                        </select>
                                    </div>
                                    <div class="col-span-1 sm:col-span-1">

                                        <label for="dayCategory"
                                            class="block mb-2 text-sm  text-left font-medium text-gray-900 dark:text-white">Select
                                            Day</label>
                                        <select id="dayCategory"
                                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500">
                                            <option></option>
                                            <option value="TUESDAY 10.00 - 11.00">TUESDAY 10.00 - 11.00</option>
                                            <option value="MONDAY 13.00 - 14.00">MONDAY 13.00 - 14.00</option>
                                            <!-- <option>Wednesday</option>
                                               <option>Thursday</option>
                                               <option>Friday</option>
                                               <option>Saturday</option> -->
                                        </select>
                                    </div>
                                </div>



                                <div class="col-span-2 sm:col-span-1">
                                    <label for="phoneNumber" 
                                        class="block mb-2 text-sm  text-left font-medium text-gray-900 dark:text-white">Phone</label>
                                    <input type="text" id="phoneNumber"
                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                        placeholder="Phonenumber">
                                </div>


                                <div class="grid grid-cols-2 lg:grid-cols-2  gap-4 py-4">

                                    <div>

                                        <div>
                                            <button @click.prevent="onBuy"
                                                class="w-full text-white bg-black hover:bg-gray-500 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                                                <label class="">Confirm</label>
                                            </button>
                                        </div>

                                    </div>

                                    <div>
                                        <div>
                                            <button @click="onCancel"
                                                class="w-full text-white bg-red-700 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-800">
                                                <label class="">Cancel</label>
                                            </button>
                                        </div>
                                    </div>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>


            </figure>

        </div>
    </div>
    <br>
    <br>
    <br>



    <div class="flex justify-center font-bold text-4xl">WHAT TO BRING</div>
    <div class="flex flex-wrap justify-center gap-28 mt-16 w-full h-1/4">
        <div>
            <img class="h-[140px] ml-2" src="../assets/water.png">
            <h1 class="text-center text-lg  mt-2">Water</h1>
        </div>

        <div>
            <img class="h-[140px]" src="../assets/towel.png">
            <h1 class="text-center text-lg  mt-2">Towel</h1>
        </div>

        <div>
            <img class="h-[140px]" src="../assets/shoes.png">
            <h1 class="text-center text-lg  mt-2">shoes</h1>
        </div>
    </div>

    <br>
    <br>
    <br>
    <br>

    <div class=" lg:flex md:flex   justify-center  gap-4  p-4 ">

        <div
            class="w-full max-w-sm    p-4 bg-white border border-gray-200 rounded-lg shadow sm:p-8 dark:bg-gray-800 dark:border-gray-700">
            <h5 class="mb-4 text-xl font-medium text-gray-500 dark:text-gray-400">Standard plan</h5>
            <div class="flex items-baseline text-gray-900 dark:text-white">
                <span class="text-3xl font-semibold">$</span>
                <span class="text-5xl font-extrabold tracking-tight">49</span>
                <span class="ms-1 text-xl font-normal text-gray-500 dark:text-gray-400">/month</span>
            </div>
            <ul role="list" class="space-y-5 my-7">
                <li class="flex items-center">
                    <svg class="flex-shrink-0 w-4 h-4 text-blue-600 dark:text-blue-500" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                        <path
                            d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5Zm3.707 8.207-4 4a1 1 0 0 1-1.414 0l-2-2a1 1 0 0 1 1.414-1.414L9 10.586l3.293-3.293a1 1 0 0 1 1.414 1.414Z" />
                    </svg>
                    <span class="text-base font-normal leading-tight text-gray-500 dark:text-gray-400 ms-3">1
                        members</span>
                </li>
                <li class="flex">
                    <svg class="flex-shrink-0 w-4 h-4 text-blue-600 dark:text-blue-500" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                        <path
                            d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5Zm3.707 8.207-4 4a1 1 0 0 1-1.414 0l-2-2a1 1 0 0 1 1.414-1.414L9 10.586l3.293-3.293a1 1 0 0 1 1.414 1.414Z" />
                    </svg>
                    <span class="text-base font-normal leading-tight text-gray-500 dark:text-gray-400 ms-3">Free water
                        refill service
                        storage</span>
                </li>
                <li class="flex">
                    <svg class="flex-shrink-0 w-4 h-4 text-blue-600 dark:text-blue-500" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                        <path
                            d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5Zm3.707 8.207-4 4a1 1 0 0 1-1.414 0l-2-2a1 1 0 0 1 1.414-1.414L9 10.586l3.293-3.293a1 1 0 0 1 1.414 1.414Z" />
                    </svg>
                    <span class="text-base font-normal leading-tight text-gray-500 dark:text-gray-400 ms-3">Exercise
                        equipment service</span>
                </li>

            </ul>
            <RouterLink to="/payment" type="button"
                class="mt-[160px] text-white bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-200 dark:focus:ring-blue-900 font-medium rounded-lg text-sm px-5 py-2.5 inline-flex justify-center w-full text-center">
                Buy now
            </RouterLink>
        </div>



        <div
            class="w-full max-w-sm p-4 bg-white border border-gray-200 rounded-lg shadow  sm:p-8 dark:bg-gray-800 dark:border-gray-700">
            <h5 class="mb-4 text-xl font-medium text-gray-500 dark:text-gray-400">Standard plan</h5>
            <div class="flex items-baseline text-gray-900 dark:text-white">
                <span class="text-3xl font-semibold">$</span>
                <span class="text-5xl font-extrabold tracking-tight">79</span>
                <span class="ms-1 text-xl font-normal text-gray-500 dark:text-gray-400">/month</span>
            </div>
            <ul role="list" class="space-y-5 my-7">
                <li class="flex items-center">
                    <svg class="flex-shrink-0 w-4 h-4 text-blue-600 dark:text-blue-500" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                        <path
                            d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5Zm3.707 8.207-4 4a1 1 0 0 1-1.414 0l-2-2a1 1 0 0 1 1.414-1.414L9 10.586l3.293-3.293a1 1 0 0 1 1.414 1.414Z" />
                    </svg>
                    <span class="text-base font-normal leading-tight text-gray-500 dark:text-gray-400 ms-3">1 members
                    </span>
                </li>
                <li class="flex">
                    <svg class="flex-shrink-0 w-4 h-4 text-blue-600 dark:text-blue-500" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                        <path
                            d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5Zm3.707 8.207-4 4a1 1 0 0 1-1.414 0l-2-2a1 1 0 0 1 1.414-1.414L9 10.586l3.293-3.293a1 1 0 0 1 1.414 1.414Z" />
                    </svg>
                    <span class="text-base font-normal leading-tight text-gray-500 dark:text-gray-400 ms-3">Free
                        Bathroom service</span>
                </li>
                <li class="flex">
                    <svg class="flex-shrink-0 w-4 h-4 text-blue-600 dark:text-blue-500" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                        <path
                            d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5Zm3.707 8.207-4 4a1 1 0 0 1-1.414 0l-2-2a1 1 0 0 1 1.414-1.414L9 10.586l3.293-3.293a1 1 0 0 1 1.414 1.414Z" />
                    </svg>
                    <span class="text-base font-normal leading-tight text-gray-500 dark:text-gray-400 ms-3">Free body
                        fat check</span>
                </li>
                <li class="flex  ">
                    <svg class="flex-shrink-0 w-4 h-4 text-blue-600 dark:text-gray-500" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                        <path
                            d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5Zm3.707 8.207-4 4a1 1 0 0 1-1.414 0l-2-2a1 1 0 0 1 1.414-1.414L9 10.586l3.293-3.293a1 1 0 0 1 1.414 1.414Z" />
                    </svg>
                    <span class="text-base font-normal leading-tight text-gray-500 ms-3">Free WiFi</span>
                </li>
                <li class="flex  decoration-gray-500">
                    <svg class="flex-shrink-0 w-4 h-4 text-blue-600 dark:text-gray-500" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                        <path
                            d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5Zm3.707 8.207-4 4a1 1 0 0 1-1.414 0l-2-2a1 1 0 0 1 1.414-1.414L9 10.586l3.293-3.293a1 1 0 0 1 1.414 1.414Z" />
                    </svg>
                    <span class="text-base font-normal leading-tight text-gray-500 ms-3">Free nutrition
                        consultation</span>
                </li>

            </ul>
            <RouterLink to="/payment2" type="button"
                class="mt-[80px] text-white bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-200 dark:focus:ring-blue-900 font-medium rounded-lg text-sm px-5 py-2.5 inline-flex justify-center w-full text-center">
                Buy now
            </RouterLink>
        </div>

    </div>

    <br>
    <br>
    <br>
    <br>

    <hr>
    <div>
        <footer class="bg-white   dark:bg-gray-900">
            <div class="mx-auto w-full max-w-screen-full text-center ">
                <div class="grid grid-cols-2 gap-8 px-4 py-6 lg:py-8 md:grid-cols-4">
                    <div>
                        <h2 class="mb-6 text-sm font-semibold text-gray-900 uppercase dark:text-white">Company</h2>
                        <ul class="text-gray-500 dark:text-gray-400 font-medium">
                            <li class="mb-4">
                                <a href="#" class=" hover:underline">Fitness center</a>
                            </li>
                            <li class="mb-4">
                                <a href="#" class="hover:underline">Careers</a>
                            </li>
                            <li class="mb-4">
                                <a href="#" class="hover:underline">Brand Center</a>
                            </li>
                            <li class="mb-4">
                                <a href="#" class="hover:underline">Blog</a>
                            </li>
                        </ul>
                    </div>
                    <div>
                        <h2 class="mb-6 text-sm font-semibold text-gray-900 uppercase dark:text-white">Help center</h2>
                        <ul class="text-gray-500 dark:text-gray-400 font-medium">
                            <li class="mb-4">
                                <a href="#" class="hover:underline">Instagram</a>
                            </li>
                            <li class="mb-4">
                                <a href="#" class="hover:underline">Twitter</a>
                            </li>
                            <li class="mb-4">
                                <a href="#" class="hover:underline">Facebook</a>
                            </li>
                            <li class="mb-4">
                                <a href="#" class="hover:underline">Contact Us</a>
                            </li>
                        </ul>
                    </div>
                    <div>
                        <h2 class="mb-6 text-sm font-semibold text-gray-900 uppercase dark:text-white">Policy</h2>
                        <ul class="text-gray-500 dark:text-gray-400 font-medium">
                            <li class="mb-4">
                                <a href="#" class="hover:underline">Privacy Policy</a>
                            </li>
                            <li class="mb-4">
                                <a href="#" class="hover:underline">Licensing</a>
                            </li>
                            <li class="mb-4">
                                <a href="#" class="hover:underline">Terms &amp; Conditions</a>
                            </li>
                        </ul>
                    </div>
                    <div>
                        <h2 class="mb-6 text-sm font-semibold text-gray-900 uppercase dark:text-white">service</h2>
                        <ul class="text-gray-500 dark:text-gray-400 font-medium">
                            <li class="mb-4">
                                <a href="#" class="hover:underline">Bathroom</a>
                            </li>
                            <li class="mb-4">
                                <a href="#" class="hover:underline">Gym</a>
                            </li>
                            <li class="mb-4">
                                <a href="#" class="hover:underline">Clean food store</a>
                            </li>
                            <li class="mb-4">
                                <a href="#" class="hover:underline">Locker</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="px-4 py-6 bg-gray-100 dark:bg-gray-700 md:flex md:items-center md:justify-between">
                    <span class="text-sm text-gray-500 dark:text-gray-300 sm:text-center"> @ 2023 <a
                            href="https://flowbite.com/">Fitness</a>Center@gmail.com
                    </span>
                    <div class="flex mt-4 sm:justify-center md:mt-0 space-x-5 rtl:space-x-reverse">
                        <a href="#" class="text-gray-400 hover:text-gray-900 dark:hover:text-white">
                            <svg class="w-4 h-4" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                fill="currentColor" viewBox="0 0 8 19">
                                <path fill-rule="evenodd"
                                    d="M6.135 3H8V0H6.135a4.147 4.147 0 0 0-4.142 4.142V6H0v3h2v9.938h3V9h2.021l.592-3H5V3.591A.6.6 0 0 1 5.592 3h.543Z"
                                    clip-rule="evenodd" />
                            </svg>
                            <span class="sr-only">Facebook page</span>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-gray-900 dark:hover:text-white">
                            <svg class="w-4 h-4" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                fill="currentColor" viewBox="0 0 21 16">
                                <path
                                    d="M16.942 1.556a16.3 16.3 0 0 0-4.126-1.3 12.04 12.04 0 0 0-.529 1.1 15.175 15.175 0 0 0-4.573 0 11.585 11.585 0 0 0-.535-1.1 16.274 16.274 0 0 0-4.129 1.3A17.392 17.392 0 0 0 .182 13.218a15.785 15.785 0 0 0 4.963 2.521c.41-.564.773-1.16 1.084-1.785a10.63 10.63 0 0 1-1.706-.83c.143-.106.283-.217.418-.33a11.664 11.664 0 0 0 10.118 0c.137.113.277.224.418.33-.544.328-1.116.606-1.71.832a12.52 12.52 0 0 0 1.084 1.785 16.46 16.46 0 0 0 5.064-2.595 17.286 17.286 0 0 0-2.973-11.59ZM6.678 10.813a1.941 1.941 0 0 1-1.8-2.045 1.93 1.93 0 0 1 1.8-2.047 1.919 1.919 0 0 1 1.8 2.047 1.93 1.93 0 0 1-1.8 2.045Zm6.644 0a1.94 1.94 0 0 1-1.8-2.045 1.93 1.93 0 0 1 1.8-2.047 1.918 1.918 0 0 1 1.8 2.047 1.93 1.93 0 0 1-1.8 2.045Z" />
                            </svg>
                            <span class="sr-only">Discord community</span>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-gray-900 dark:hover:text-white">
                            <svg class="w-4 h-4" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                fill="currentColor" viewBox="0 0 20 17">
                                <path fill-rule="evenodd"
                                    d="M20 1.892a8.178 8.178 0 0 1-2.355.635 4.074 4.074 0 0 0 1.8-2.235 8.344 8.344 0 0 1-2.605.98A4.13 4.13 0 0 0 13.85 0a4.068 4.068 0 0 0-4.1 4.038 4 4 0 0 0 .105.919A11.705 11.705 0 0 1 1.4.734a4.006 4.006 0 0 0 1.268 5.392 4.165 4.165 0 0 1-1.859-.5v.05A4.057 4.057 0 0 0 4.1 9.635a4.19 4.19 0 0 1-1.856.07 4.108 4.108 0 0 0 3.831 2.807A8.36 8.36 0 0 1 0 14.184 11.732 11.732 0 0 0 6.291 16 11.502 11.502 0 0 0 17.964 4.5c0-.177 0-.35-.012-.523A8.143 8.143 0 0 0 20 1.892Z"
                                    clip-rule="evenodd" />
                            </svg>
                            <span class="sr-only">Twitter page</span>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-gray-900 dark:hover:text-white">
                            <svg class="w-4 h-4" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd"
                                    d="M10 .333A9.911 9.911 0 0 0 6.866 19.65c.5.092.678-.215.678-.477 0-.237-.01-1.017-.014-1.845-2.757.6-3.338-1.169-3.338-1.169a2.627 2.627 0 0 0-1.1-1.451c-.9-.615.07-.6.07-.6a2.084 2.084 0 0 1 1.518 1.021 2.11 2.11 0 0 0 2.884.823c.044-.503.268-.973.63-1.325-2.2-.25-4.516-1.1-4.516-4.9A3.832 3.832 0 0 1 4.7 7.068a3.56 3.56 0 0 1 .095-2.623s.832-.266 2.726 1.016a9.409 9.409 0 0 1 4.962 0c1.89-1.282 2.717-1.016 2.717-1.016.366.83.402 1.768.1 2.623a3.827 3.827 0 0 1 1.02 2.659c0 3.807-2.319 4.644-4.525 4.889a2.366 2.366 0 0 1 .673 1.834c0 1.326-.012 2.394-.012 2.72 0 .263.18.572.681.475A9.911 9.911 0 0 0 10 .333Z"
                                    clip-rule="evenodd" />
                            </svg>
                            <span class="sr-only">GitHub account</span>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-gray-900 dark:hover:text-white">
                            <svg class="w-4 h-4" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd"
                                    d="M10 0a10 10 0 1 0 10 10A10.009 10.009 0 0 0 10 0Zm6.613 4.614a8.523 8.523 0 0 1 1.93 5.32 20.094 20.094 0 0 0-5.949-.274c-.059-.149-.122-.292-.184-.441a23.879 23.879 0 0 0-.566-1.239 11.41 11.41 0 0 0 4.769-3.366ZM8 1.707a8.821 8.821 0 0 1 2-.238 8.5 8.5 0 0 1 5.664 2.152 9.608 9.608 0 0 1-4.476 3.087A45.758 45.758 0 0 0 8 1.707ZM1.642 8.262a8.57 8.57 0 0 1 4.73-5.981A53.998 53.998 0 0 1 9.54 7.222a32.078 32.078 0 0 1-7.9 1.04h.002Zm2.01 7.46a8.51 8.51 0 0 1-2.2-5.707v-.262a31.64 31.64 0 0 0 8.777-1.219c.243.477.477.964.692 1.449-.114.032-.227.067-.336.1a13.569 13.569 0 0 0-6.942 5.636l.009.003ZM10 18.556a8.508 8.508 0 0 1-5.243-1.8 11.717 11.717 0 0 1 6.7-5.332.509.509 0 0 1 .055-.02 35.65 35.65 0 0 1 1.819 6.476 8.476 8.476 0 0 1-3.331.676Zm4.772-1.462A37.232 37.232 0 0 0 13.113 11a12.513 12.513 0 0 1 5.321.364 8.56 8.56 0 0 1-3.66 5.73h-.002Z"
                                    clip-rule="evenodd" />
                            </svg>
                            <span class="sr-only">Dribbble account</span>
                        </a>
                    </div>
                </div>
            </div>
        </footer>
    </div>


</template>

<script setup>

import { ref } from 'vue'
import { Disclosure, DisclosureButton, DisclosurePanel, Menu, MenuButton, MenuItem, MenuItems, } from '@headlessui/vue'
import { Bars3Icon, BellIcon, XMarkIcon } from '@heroicons/vue/24/outline'
import { RouterLink } from 'vue-router'
import Nav from '@/components/Nav.vue'
import Swal from 'sweetalert2';
import { onMounted } from "vue";
import { initFlowbite } from "flowbite";
import { useToast } from "vue-toastification";

onMounted(() => {
    initFlowbite()
});

const open = ref(true)
const navigation = [
    { name: 'Member ship', href: '/', current: true },
    { name: 'About', href: '/about', current: false },
    { name: 'Projects', href: '#', current: false },
    { name: 'Calendar', href: '#', current: false },
]



const token = localStorage.getItem("accessToken");
const userObject = JSON.parse(localStorage.getItem("userObj"))
const toast = useToast();
import axios from 'axios';


const onBuy = () => {
    const userId = userObject?._id;
    const selectedClassElement = document.getElementById("classCategory");
    const selectedDayElement = document.getElementById("dayCategory");
    const phoneNumberElement = document.getElementById("phoneNumber");

    if (!userId || !selectedClassElement || !selectedDayElement || !phoneNumberElement) {
        console.error("Missing required data or elements");
        return;
    }

    const selectedClass = selectedClassElement.value;
    const selectedDay = selectedDayElement.value;
    const phoneNumber = phoneNumberElement.value;
    

    // ตรวจสอบว่าไม่มีค่าว่าง
    if (!userId || !selectedClass || !selectedDay || !phoneNumber) {
        console.error("Missing required data");
        return;
    }

    const requestData = {
        userId: userId,
        SelectClass: selectedClass,
        SelectDay: selectedDay,
        phoneNumber: phoneNumber,
    };

    const config = {
        headers: {
            'Authorization': `Bearer ${token}`, // เพิ่ม Token ใน Authorization header
        }
    };

    axios.post('http://localhost:8080/api/v1/users/reserveClass', requestData , config)
        .then(response => {
            toast.success("Buy Success", {
                position: "top-right",
                timeout: 1000,
            });
            setTimeout(() => {
                location.reload();
            }, 1000);
        })
        .catch(error => {
            console.error('Error while sending POST request:', error);
            // แสดงข้อความแจ้งเตือนหรือจัดการตามต้องการ
        });
};

const onCancel = () => {
    location.reload();
};


</script>