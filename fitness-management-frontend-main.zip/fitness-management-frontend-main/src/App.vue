<script setup>
import { RouterLink, RouterView } from 'vue-router'
import login from './views/login.vue';


</script>

<template>

<RouterView></RouterView>
<RouterLink></RouterLink>
      
</template>

